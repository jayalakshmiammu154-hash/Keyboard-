# Neon Keys — Android custom keyboard

A Kotlin Android Input Method Editor (IME) starter project with:
- Dark / cyan gaming theme
- 28 editable keyboard cells; tap a cell in the editor and assign a letter, digit, or symbol
- Custom layouts saved locally, with a layout selector and create-layout button
- Adjustable key height and spacing
- Number and symbol layers, backspace, space, shift, and enter/action key
- Android system keyboard activation flow

## Build on Android / PC
1. Open this folder in Android Studio (Giraffe or newer; current stable recommended).
2. Let Gradle sync and install the Android SDK platform 35 if prompted.
3. Build > Build APK(s), or run on a connected Android device.
4. Install the generated APK.
5. Open **Neon Keys**, tap **Enable keyboard**, enable Neon Keys in Android's input method settings.
6. Open a text field and choose Neon Keys from the system keyboard picker.

## No PC?
The source project is provided, but compiling an APK generally requires Android build tools. You can use an Android IDE/build environment that supports Gradle projects, or a trusted cloud build setup. Do not install APKs from unknown sites.

## Notes / limitations
- This is a complete starter implementation, not a verified release APK; it has not been built or device-tested in this environment.
- Keyboard settings and layouts are stored locally with SharedPreferences.
- The editor lets you assign any supported character to any of the 28 grid positions. This is position-based editing rather than drag-and-drop.
- Word prediction, autocorrect, swipe typing, emoji picker, clipboard history, and multilingual dictionaries are not included.
- Keep the initial keyboard layout usable: putting no backspace/space/enter keys in the alphabet grid does not remove the dedicated control rows/layers; the current design places these controls in number/symbol layers, so preserve or assign SPACE/backspace/enter controls only if extending the key model.
- For production, add tests, accessibility descriptions, privacy disclosures, and more robust settings validation.
