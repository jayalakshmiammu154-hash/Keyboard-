package com.example.neonkeys

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var grid: GridLayout
    private val cyan = Color.rgb(0, 229, 255)
    private val bg = Color.rgb(13, 16, 27)
    private val letters = (('A'..'Z').map { it.toString() } + listOf("", "⌫", "SPACE", "↵", "⇧", "123", "SYM", "⚙"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 18)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "NEON KEYS  /  CUSTOM LAB"
            textSize = 21f; setTextColor(cyan); typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "Tap a cell, then choose the character to put there. Empty cells are allowed."
            textSize = 13f; setTextColor(Color.LTGRAY); setPadding(0, 8, 0, 14)
        })
        val layoutRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val spinner = Spinner(this)
        fun refreshSpinner(): Array<String> = KeyboardPrefs.layouts(this).sorted().toTypedArray()
        var names = refreshSpinner()
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        spinner.setSelection(names.indexOf(KeyboardPrefs.active(this)).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                if (position in names.indices) { KeyboardPrefs.setActive(this@SettingsActivity, names[position]); renderGrid() }
            }
        }
        layoutRow.addView(spinner, LinearLayout.LayoutParams(0, 48, 1f))
        val add = Button(this).apply {
            text = "+ Layout"
            setOnClickListener {
                val input = EditText(this@SettingsActivity).apply { hint = "Layout name" }
                AlertDialog.Builder(this@SettingsActivity).setTitle("Create layout").setView(input)
                    .setPositiveButton("Create") { _, _ ->
                        val n = input.text.toString().trim()
                        if (n.isNotEmpty()) {
                            KeyboardPrefs.createLayout(this@SettingsActivity, n)
                            names = refreshSpinner()
                            spinner.adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, names)
                            spinner.setSelection(names.indexOf(n).coerceAtLeast(0))
                            renderGrid()
                        }
                    }.setNegativeButton("Cancel", null).show()
            }
        }
        layoutRow.addView(add)
        root.addView(layoutRow)

        grid = GridLayout(this).apply { columnCount = 7; rowCount = 4; useDefaultMargins = false }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 12; bottomMargin = 8 })

        root.addView(TextView(this).apply {
            text = "KEY SIZE"; setTextColor(cyan); textSize = 12f
        })
        val size = SeekBar(this).apply {
            max = 58; progress = KeyboardPrefs.size(this@SettingsActivity) - 30
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { KeyboardPrefs.setSize(this@SettingsActivity, p + 30) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(size)
        root.addView(TextView(this).apply { text = "KEY SPACING"; setTextColor(cyan); textSize = 12f })
        root.addView(SeekBar(this).apply {
            max = 16; progress = KeyboardPrefs.gap(this@SettingsActivity)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { KeyboardPrefs.setGap(this@SettingsActivity, p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Button(this).apply { text = "Reset letters"; setOnClickListener {
            KeyboardPrefs.saveKeys(this@SettingsActivity, KeyboardPrefs.defaultKeys()); renderGrid()
        } }, LinearLayout.LayoutParams(0, 52, 1f))
        buttons.addView(Button(this).apply { text = "Enable keyboard"; setOnClickListener {
            startActivity(Intent("android.settings.INPUT_METHOD_SETTINGS"))
        } }, LinearLayout.LayoutParams(0, 52, 1f))
        root.addView(buttons)
        root.addView(TextView(this).apply {
            text = "After enabling: open any text field, switch keyboards using the system keyboard picker."
            textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0, 8, 0, 0)
        })
        setContentView(root)
        renderGrid()
    }

    private fun renderGrid() {
        if (!::grid.isInitialized) return
        grid.removeAllViews()
        val keys = KeyboardPrefs.keys(this)
        for (i in 0 until 28) {
            val label = keys.getOrElse(i) { "" }
            val b = Button(this).apply {
                text = if (label.isBlank()) "·" else label
                textSize = 14f
                isAllCaps = false
                setTextColor(if (label.isBlank()) Color.GRAY else cyan)
                setBackgroundColor(Color.rgb(28, 34, 49))
                setOnClickListener { editCell(i, keys) }
            }
            val lp = GridLayout.LayoutParams().apply {
                width = 0; height = (KeyboardPrefs.size(this@SettingsActivity) + 12).dp()
                columnSpec = GridLayout.spec(i % 7, 1f)
                rowSpec = GridLayout.spec(i / 7)
                setMargins(KeyboardPrefs.gap(this@SettingsActivity) / 2, 3, KeyboardPrefs.gap(this@SettingsActivity) / 2, 3)
            }
            grid.addView(b, lp)
        }
    }

    private fun editCell(index: Int, keys: MutableList<String>) {
        val options = (('A'..'Z').map { it.toString() } + listOf("0","1","2","3","4","5","6","7","8","9",
            ".",",","?","!","'","\"","@","#","$","%","&","(",")","-","+","=","/",";",":","_","· (empty)")).toTypedArray()
        AlertDialog.Builder(this).setTitle("Set key ${index + 1}")
            .setItems(options) { _, which ->
                val chosen = options[which]
                keys[index] = if (chosen == "· (empty)") "" else chosen
                KeyboardPrefs.saveKeys(this, keys)
                renderGrid()
            }.setNeutralButton("Clear") { _, _ -> keys[index] = ""; KeyboardPrefs.saveKeys(this, keys); renderGrid() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()
}
