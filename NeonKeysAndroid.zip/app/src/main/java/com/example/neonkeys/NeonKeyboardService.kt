package com.example.neonkeys

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class NeonKeyboardService : InputMethodService() {
    private val cyan = Color.rgb(0, 229, 255)
    private val background = Color.rgb(13, 16, 27)
    private var symbols = false
    private var numbers = false
    private var caps = false

    override fun onCreateInputView(): View = makeKeyboard()

    private fun makeKeyboard(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 6, 4, 6)
            setBackgroundColor(background)
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(actionButton("⚙", 0.8f) {
            startActivity(android.content.Intent(this@NeonKeyboardService, SettingsActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        top.addView(TextView(this).apply {
            text = "NEON KEYS"; setTextColor(cyan); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, 34, 1f))
        top.addView(actionButton("⇧", 0.8f) { caps = !caps; setInputView(makeKeyboard()) })
        outer.addView(top)

        val custom = KeyboardPrefs.keys(this)
        val display = if (symbols) listOf(
            listOf("!","@","#","$","%","&","*"),
            listOf("(",")","-","+","=","/","?"),
            listOf(",",".",":",";","'","\"","_"),
            listOf("SYM","123","SPACE","⌫","↵","","")
        ) else if (numbers) listOf(
            listOf("1","2","3","4","5","6","7"),
            listOf("8","9","0","-","/",":",";"),
            listOf("("," )","$","&","@","\"","?"),
            listOf("ABC","SYM","SPACE","⌫","↵","","")
        ) else (0 until 4).map { row -> (0 until 7).map { col -> custom.getOrElse(row * 7 + col) { "" } } }

        display.forEachIndexed { rowIndex, row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            row.forEachIndexed { colIndex, key ->
                val lp = LinearLayout.LayoutParams(0, (KeyboardPrefs.size(this) + 8).dp(), 1f).apply {
                    setMargins((KeyboardPrefs.gap(this) / 2).dp(), 2.dp(), (KeyboardPrefs.gap(this) / 2).dp(), 2.dp())
                }
                val label = when (key) {
                    "SPACE" -> "␣"
                    "⌫" -> "⌫"
                    "↵" -> "↵"
                    "SYM" -> "SYM"
                    "ABC" -> "ABC"
                    "123" -> "123"
                    else -> if (caps) key.uppercase() else key.lowercase()
                }
                val button = Button(this).apply {
                    text = label
                    isAllCaps = false
                    textSize = if (key.length > 3) 10f else 16f
                    setTextColor(if (key.isBlank()) Color.GRAY else cyan)
                    background = GradientDrawable().apply {
                        setColor(if (key.isBlank()) Color.rgb(19, 23, 35) else Color.rgb(28, 34, 49))
                        cornerRadius = 8.dp().toFloat()
                        setStroke(1.dp(), Color.rgb(0, 95, 120))
                    }
                    setPadding(0, 0, 0, 0)
                    setOnClickListener { handleKey(key) }
                }
                line.addView(button, lp)
            }
            outer.addView(line)
        }

        // Persistent utility row so the custom alphabet layout always remains usable.
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("SYM", "123", "SPACE", "⌫", "↵").forEach { key ->
            controls.addView(actionButton(
                when (key) { "SPACE" -> "space"; "⌫" -> "⌫"; "↵" -> "↵"; else -> key },
                if (key == "SPACE") 2.8f else 1f
            ) { handleKey(key) }, LinearLayout.LayoutParams(0, 42.dp(), if (key == "SPACE") 2.8f else 1f).apply {
                setMargins(2.dp(), 2.dp(), 2.dp(), 2.dp())
            })
        }
        outer.addView(controls)
        return outer
    }

    private fun handleKey(key: String) {
        val ic = currentInputConnection ?: return
        when (key) {
            "" -> return
            "⌫" -> ic.deleteSurroundingText(1, 0)
            "↵" -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
                if (action != null && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED)
                    ic.performEditorAction(action)
                else ic.commitText("\n", 1)
            }
            "SPACE" -> ic.commitText(" ", 1)
            "SYM" -> { symbols = !symbols; numbers = false; setInputView(makeKeyboard()) }
            "123" -> { numbers = !numbers; symbols = false; setInputView(makeKeyboard()) }
            "ABC" -> { numbers = false; symbols = false; setInputView(makeKeyboard()) }
            "⇧" -> { caps = !caps; setInputView(makeKeyboard()) }
            "⚙" -> startActivity(android.content.Intent(this, SettingsActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
            else -> ic.commitText(if (caps) key.uppercase() else key.lowercase(), 1)
        }
    }

    private fun actionButton(textValue: String, weight: Float, click: () -> Unit) = Button(this).apply {
        text = textValue; isAllCaps = false; textSize = 14f; setTextColor(cyan)
        setBackgroundColor(Color.rgb(28, 34, 49)); setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(0, 34.dp(), weight)
    }
    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()
}
