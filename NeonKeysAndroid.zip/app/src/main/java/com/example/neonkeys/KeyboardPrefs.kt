package com.example.neonkeys

import android.content.Context

object KeyboardPrefs {
    private const val PREF = "neon_keys"
    private const val ACTIVE = "active_layout"
    private const val SIZE = "key_size"
    private const val GAP = "key_gap"

    fun layouts(context: Context): MutableSet<String> =
        context.getSharedPreferences(PREF, 0).getStringSet("layouts", setOf("Default"))!!.toMutableSet()

    fun active(context: Context): String =
        context.getSharedPreferences(PREF, 0).getString(ACTIVE, "Default") ?: "Default"

    fun setActive(context: Context, name: String) {
        context.getSharedPreferences(PREF, 0).edit().putString(ACTIVE, name).apply()
    }

    fun createLayout(context: Context, name: String) {
        val p = context.getSharedPreferences(PREF, 0)
        val set = p.getStringSet("layouts", setOf("Default"))!!.toMutableSet()
        set.add(name)
        p.edit().putStringSet("layouts", set).apply()
        if (p.getString("layout_$name", null) == null) {
            p.edit().putString("layout_$name", defaultKeys().joinToString("|")).apply()
        }
        setActive(context, name)
    }

    fun keys(context: Context): MutableList<String> {
        val p = context.getSharedPreferences(PREF, 0)
        val name = active(context)
        val raw = p.getString("layout_$name", null)
        return if (raw == null) defaultKeys().toMutableList()
        else raw.split("|").toMutableList().also { while (it.size < 28) it.add("") }
    }

    fun saveKeys(context: Context, keys: List<String>) {
        context.getSharedPreferences(PREF, 0).edit()
            .putString("layout_${active(context)}", keys.take(28).joinToString("|")).apply()
    }

    fun size(context: Context): Int = context.getSharedPreferences(PREF, 0).getInt(SIZE, 42)
    fun setSize(context: Context, value: Int) { context.getSharedPreferences(PREF, 0).edit().putInt(SIZE, value).apply() }
    fun gap(context: Context): Int = context.getSharedPreferences(PREF, 0).getInt(GAP, 5)
    fun setGap(context: Context, value: Int) { context.getSharedPreferences(PREF, 0).edit().putInt(GAP, value).apply() }

    fun defaultKeys(): List<String> = listOf(
        "Q","W","E","R","T","Y","U",
        "I","O","P","A","S","D","F",
        "G","H","J","K","L","Z","X",
        "C","V","B","N","M","",""
    )
}
